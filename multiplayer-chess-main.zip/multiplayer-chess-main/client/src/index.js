// rode os seguintes códigos no terminal do client:
// 1:  npx create-react-app .
// 2:  npm install react-chessboard chess.js socket.io-client @mui/material @emotion/react @emotion/styled



import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);